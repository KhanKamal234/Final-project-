# Karachi Mart Final Project

A clean standalone HTML, CSS and JavaScript grocery website.

## Open

Open `index.html` in a browser.

## Pages

- `index.html`: shop, search, categories, offers and cart access
- `login.html` / `signup.html`: matching demo account flow
- `cart.html`: quantities, delete and totals
- `checkout.html`: delivery and payment details
- `bill.html`: printable invoice
- `profile.html`: profile photo, order summary and logout

This final classroom version uses browser `localStorage` so signup and login match without Firebase configuration. It is suitable for a front-end project demonstration. A production website should replace the demo auth with a secure backend and hashed passwords.
